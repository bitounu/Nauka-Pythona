# Listing_5-1.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Pobieranie �a�cucha za pomoc� funkcji raw_input()

print "Wprowad� swoje imi�: "
ktos = raw_input()
print "Cze��,", ktos, ", jak si� masz?"

