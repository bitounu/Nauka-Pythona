# Listing_8-5.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Wy�wietlanie tabliczki mno�enia (do dziesi�ciu) liczby 8 za pomoc� funkcji range()

for petla in range (1, 11):
    print petla, "razy 8 =", petla * 8

