# Listing_16-1.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Pr�ba wywo�ania okna Pygame

import pygame
pygame.init()
ekran = pygame.display.set_mode([640, 480])

