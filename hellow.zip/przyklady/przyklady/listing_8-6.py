# Listing_8-6.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Gotowi do startu? (odliczanie)

import time
for i in range(10, 0, -1):  # Odliczanie
    print i
    time.sleep(1)           # Odczekanie jednej sekundy
print "START!"

