"""
Nazwa SI: Pusta SI

Autor: Carter

Strategia:
Nic nie robi.
"""


class SI:
    def tura(self):
        self.robot.nicNieRob()
