# Listing_15-1.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# zapisz ten plik pod nazw� "moj_modul.py"
# wykorzystamy go w innym programie
def c_na_f(celsjusze):
    fahrenheity = celsjusze * 9.0 / 5 + 32
    return fahrenheity


