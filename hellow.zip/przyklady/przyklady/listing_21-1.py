# Listing_21-1.py
# Copyright Warren & Csrter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Program wy�wietlaj�cy kwadraty i sze�ciany kilku liczb

print "Liczba \tKwadrat\tSze�cian"
for i in range (1, 11):
    print i, '\t', i**2, '\t', i**3

