# Listing_13-2
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Przekazywanie argumentu do funkcji

# definiujemy funkcj� z argumentem
def wyswietlMojAdres(mojeImieNazwisko):
    print mojeImieNazwisko          # przekazali�my do funkcji warto�� w zmiennej mojeImieNazwisko
    print "ul. Kasztanowa 23"
    print "44-100 Gliwice"
    print "Polska"
    print

# wywo�ujemy funkcj� i przekazujemy do niej argument
wyswietlMojAdres("Maciek Kowalski")
