# Listing_13-1
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Tworzenie funkcji i korzystanie z niej

# definiujemy funkcj�
def wyswietlMojAdres():
    print "Adam Kowalski"
    print "ul. Kasztanowa 23"
    print "44-100 Gliwice"
    print "Polska"
    print

# g��wny program rozpoczyna si� w tym miejscu - wywo�ujemy funkcj�
wyswietlMojAdres()
