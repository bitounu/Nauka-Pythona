# Listing_8-3.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Wy�wietlanie tabliczki mno�enia dla liczby 8

for petla in [1, 2, 3, 4, 5]:
    print petla, "razy 8 =", petla * 8

