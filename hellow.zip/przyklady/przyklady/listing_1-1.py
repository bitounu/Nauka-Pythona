# Listing_1-1.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Nasz pierwszy program

print "Uwielbiam pizz�!"
print "pizza " * 20
print "mniam " * 40
print "Najad�em si�."


