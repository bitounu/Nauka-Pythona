# Listing_8-2.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Przy ka�dym przej�ciu p�tli for wykonujemy co� innego

for petla in [1, 2, 3, 4, 5]:
    print petla
