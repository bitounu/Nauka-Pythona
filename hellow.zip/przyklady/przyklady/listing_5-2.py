# Listing_5-2.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Jak dzia�a przecinek?

print "Mam",
print "na",
print "imi�",
print "Dawid."
