# Listing_8-7.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Kto jest najfajnieszy? (p�tla bez liczb)

for ktos_fajny in ["Bob Budowniczy", "Spiderman", "Justin Timberlake", "M�j Tata"]:
    print ktos_fajny, "jest najlepszy na �wiecie!"
