# Listing_15-3.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Usypianie programu

import time

print "Jak",
time.sleep(2)
print "si�",
time.sleep(2)
print "masz?"

