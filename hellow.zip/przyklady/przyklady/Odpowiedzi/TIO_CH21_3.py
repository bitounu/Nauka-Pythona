# TIO_CH21_3.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Odpowied� do zadania praktycznego 3, z rozdzia�u 21.

# Obliczamy wszystkie u�amki libczy 8
# i wy�wietlamy je z dok�adno�ci� do 3 miejsc po przecinku

for i in range(1, 9):
    ulamek = i / 8.0
    print str(i) + '/8 = %.3f' % ulamek

    
