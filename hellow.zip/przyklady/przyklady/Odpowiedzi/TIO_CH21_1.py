# TIO_CH21_1.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version $version  ----------------------------

# Odpowied� do zadania praktycznego 1, z rozdzia�u 21.

# W jednym zdaniu wy�wietlamy imi�, wiek i ulubiony kolor

imie = raw_input("Jak masz na imi�? ")
wiek = int(raw_input("Ile masz lat? "))
kolor = raw_input("Jaki jest Tw�j ulubiony kolor? ")

print "Masz na imi�", imie,
print "masz", wiek, "lat,",
print "a Tw�j ulubiony kolor to", kolor
